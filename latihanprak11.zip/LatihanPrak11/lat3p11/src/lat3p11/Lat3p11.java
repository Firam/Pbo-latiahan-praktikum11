/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lat3p11;

/**
 *
 * @author Felicia Mulia
 */
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Panel;
public class Lat3p11 extends Panel{

    /**
     * @param args the command line arguments
     */
    
    Lat3p11() {
       setBackground(Color.GRAY); //konstanta dalam class color
    }
    
     public void paint(Graphics g) {
        Font f = new Font("Helvetica", Font.BOLD,48);
        FontMetrics fm = getFontMetrics(f);
        g.setFont(f);
        
        String s = "text ini tampil ditengah";
        int xpos = (this.size().width - fm.stringWidth(s)) /2;
        int ypos = (this.size().height) /2;
        g.setFont(f);
        g.drawString(s, xpos, ypos);
    }
     
     

    public static void main(String[] args) {
        // TODO code application logic here
        Frame f = new Frame("Testing Graphics Panel");
        Lat3p11 gp = new Lat3p11();
        f.add(gp);
        f.setSize(900,900);
        f.setVisible(true);
    }
    
}
