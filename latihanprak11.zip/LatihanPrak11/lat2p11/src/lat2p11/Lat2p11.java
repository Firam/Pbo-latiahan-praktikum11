/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lat2p11;

/**
 *
 * @author Felicia Mulia
 */
import java.awt.*;
public class Lat2p11  extends Panel {

    /**
     * @param args the command line arguments
     */
    Font f;
    String text = "Halo Kharisma";
    
    Lat2p11() {
        setBackground(Color.GRAY); //konstanta dalam color
    }
    
    public void paint(Graphics g) {
        f = new Font("Helvetica", Font.BOLD,48);
        //kotak hijau
        g.setColor(Color.GREEN);
        g.fillRect(8,8,380,105);
        //warna hitam piringan
        g.setColor(Color.BLACK);
        g.drawRect(8,8,380,105);
        g.setColor(Color.yellow);
        g.fillOval(10,10,380,100);
        //diberi pinggiran warna merah tebal
        g.setColor(Color.blue);
        g.drawOval(10,10,380,100);
        g.drawOval(9,9,382,102);
        g.drawOval(8,8,384,104);
        //tulisan warna hitam dengan font helvetica
        g.setColor(Color.black);
        g.setFont(f);
        g.drawString(text,40,75);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
         Frame f = new Frame("Testing Graphics Panel");
        Lat2p11 gp = new Lat2p11();
        f.add(gp);
        f.setSize(900,900);
        f.setVisible(true);
    }
    
}
